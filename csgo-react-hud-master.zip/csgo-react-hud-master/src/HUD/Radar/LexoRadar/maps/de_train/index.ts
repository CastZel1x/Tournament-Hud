import radar from './radar.png'

const config = {
    "config": {
        "origin": {
            "x": 527.365542903922,
            "y": 511.81469648562296
        },
        "pxPerUX": 0.21532584158170223,
        "pxPerUY": -0.21299254526091588
    },
    "file":radar
}

export default config;