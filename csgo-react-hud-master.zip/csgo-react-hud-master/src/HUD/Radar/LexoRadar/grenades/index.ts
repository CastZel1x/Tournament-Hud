import Firebomb from './firebomb.png'
import Flash from './flash.png'
import Smoke from './smoke.png'

export { Firebomb, Flash, Smoke };