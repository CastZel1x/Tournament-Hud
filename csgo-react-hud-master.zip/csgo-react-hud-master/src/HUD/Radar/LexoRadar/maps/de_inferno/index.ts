import radar from './radar.png'

const config = {
    "config": {
        "origin": {
            "x": 426.51386123945593,
            "y": 790.7266981544722
        },
        "pxPerUX": 0.2041685571162696,
        "pxPerUY": -0.20465735943851654
    },
    "file":radar
}

export default config;