import radar from './radar.png'

const config = {
    "config": {
        "origin": {
            "x": 361.7243823603619,
            "y": 579.553558767951
        },
        "pxPerUX": 0.1830927328891829,
        "pxPerUY": -0.17650705879909936
    },
    "file":radar
}

export default config;