import radar from './radar.png'

const config = {
    "config": {
        "origin": {
            "x": 563.1339320329055,
            "y": 736.9535330430065
        },
        "pxPerUX": 0.2278315639654376,
        "pxPerUY": -0.22776482548619972
    },
    "file":radar
}

export default config;