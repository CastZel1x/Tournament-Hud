const config = {
    playerSize: 60,
}

export default config;